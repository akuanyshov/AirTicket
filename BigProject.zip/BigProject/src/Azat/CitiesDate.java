package Azat;

import java.io.Serializable;
import java.util.ArrayList;

public class CitiesDate implements Serializable {
    String operationType;
    ArrayList<Cities> citiesDate = new ArrayList<>();
    Cities cityDate;

    public CitiesDate(String operationType, ArrayList<Cities> cities, Cities city) {
        this.operationType = operationType;
        this.citiesDate = cities;
        this.cityDate = city;
    }

    public String getOperationType() {
        return operationType;
    }

    public void setOperationType(String operationType) {
        this.operationType = operationType;
    }

    public ArrayList<Cities> getCitiesDate() {
        return citiesDate;
    }

    public void setCitiesDate(ArrayList<Cities> citiesDate) {
        this.citiesDate = citiesDate;
    }

    public Cities getCityDate() {
        return cityDate;
    }

    public void setCityDate(Cities cityDate) {
        this.cityDate = cityDate;
    }
}

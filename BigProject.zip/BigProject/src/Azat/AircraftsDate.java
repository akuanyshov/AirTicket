package Azat;

import java.io.Serializable;
import java.util.ArrayList;

public class AircraftsDate implements Serializable {
    String operationType;
    ArrayList<Aircrafts> aircraftsDate = new ArrayList<>();
    Aircrafts aircraftDate;

    public AircraftsDate(String operationType, ArrayList<Aircrafts> aircrafts, Aircrafts aircraft) {
        this.operationType = operationType;
        this.aircraftsDate = aircrafts;
        this.aircraftDate = aircraft;
    }



    public String getOperationType() {
        return operationType;
    }

    public void setOperationType(String operationType) {
        this.operationType = operationType;
    }

    public ArrayList<Aircrafts> getAircraftsDate() {
        return aircraftsDate;
    }

    public void setAircraftsDate(ArrayList<Aircrafts> aircraftsDate) {
        this.aircraftsDate = aircraftsDate;
    }

    public Aircrafts getAircraftDate() {
        return aircraftDate;
    }

    public void setAircraftDate(Aircrafts aircraftDate) {
        this.aircraftDate = aircraftDate;
    }
}

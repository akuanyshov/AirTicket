package Azat;

import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.sql.Connection;
import java.sql.DriverManager;

public class Server {
    static Connection connection;
    public static void main(String[] args) {
        try{

            Class.forName("com.mysql.cj.jdbc.Driver");
            connection = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/bigproject?useUnicode=true&serverTimezone=UTC","root", ""
            );
            ServerSocket admin = new ServerSocket(2024);
            while (true){
                Socket socket = admin.accept();
                System.out.println("ADMIN CONNECTED");
                ServerThread st = new ServerThread(socket,connection);
                Thread thread = new Thread(st);
                thread.start();
            }
        } catch (Exception e){
            e.printStackTrace();
        }
    }
}

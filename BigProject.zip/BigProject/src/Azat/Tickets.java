package Azat;

import java.io.Serializable;

public class Tickets implements Serializable {
    private Long id;
    private Long flight_id;

}

package Azat;

import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.Scanner;

public class Admin {
    static ObjectOutputStream outputStream;

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        try {
            Socket socket = new Socket("192.168.31.10", 2024);
            outputStream = new ObjectOutputStream(socket.getOutputStream());
            AdminGUI gui =new AdminGUI();
            gui.setVisible(true);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
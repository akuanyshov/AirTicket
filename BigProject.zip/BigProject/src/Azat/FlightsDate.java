package Azat;

import java.io.Serializable;
import java.util.ArrayList;

public class FlightsDate implements Serializable {
    String operationType;
    ArrayList<Flights> flightsDate = new ArrayList<>();
    Flights flyDate;

    public FlightsDate(String operationType, ArrayList<Flights> flights, Flights fly) {
        this.operationType = operationType;
        this.flightsDate = flights;
        this.flyDate = fly;
    }

    public String getOperationType() {
        return operationType;
    }

    public void setOperationType(String operationType) {
        this.operationType = operationType;
    }

    public ArrayList<Flights> getFlightsDate() {
        return flightsDate;
    }

    public void setFlightsDate(ArrayList<Flights> flightsDate) {
        this.flightsDate = flightsDate;
    }

    public Flights getFlyDate() {
        return flyDate;
    }

    public void setFlyDate(Flights flyDate) {
        this.flyDate = flyDate;
    }
}


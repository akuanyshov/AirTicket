package Azat;

import javax.xml.transform.Result;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class ServerThread implements Runnable {
    Socket socket;
    Connection connection;

    public ServerThread(Socket socket, Connection connection) {
        this.socket = socket;
        this.connection = connection;
    }

    @Override
    public void run() {
        try {
            ObjectInputStream inputStream = new ObjectInputStream(socket.getInputStream());
            ObjectOutputStream outputStream = new ObjectOutputStream(socket.getOutputStream());
            while (true) {
                Object ob =  inputStream.readObject();
                if (ob instanceof  Aircrafts) {
                    if (((AircraftsDate)ob).getOperationType().equals("AIRCRAFTS DATE")) {
                        addAircraft(((AircraftsDate)ob).getAircraftDate());
                    }
                }
                Object ab = inputStream.readObject();
                if (ab instanceof Cities){
                    if(((CitiesDate)ab).getOperationType().equals("CITIES DATE")){
                        addCities(((CitiesDate)ab).getCityDate());
                    }
                }
                Object cb = inputStream.readObject();
                if ( cb instanceof Flights){
                    if(((FlightsDate)cb).getOperationType().equals("FLIGHTS DATE")){
                        addFlight(((FlightsDate)cb).getFlyDate());
                    }

                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void addAircraft(Aircrafts aircrafts) {
        try {
            PreparedStatement staircraft = connection.prepareStatement("INSERT INTO aircrafts(id,name,model," +
                    "business_class_capacity,econom_class_capacity) VALUES(NULL,?,?,?,?)");
            staircraft.setString(1, aircrafts.getName());
            staircraft.setString(2, aircrafts.getModel());
            staircraft.setLong(3, aircrafts.getBusiness_class_capacity());
            staircraft.setLong(4, aircrafts.getEconom_class_capacity());
            staircraft.executeUpdate();

            staircraft = connection.prepareStatement("SELECT * FROM aircrafts WHERE name=? AND model=? " +
                    "AND business_class_capacity=? AND econom_class_capacity=?");
            staircraft.setString(1, aircrafts.getName());
            staircraft.setString(2, aircrafts.getModel());
            staircraft.setLong(3, aircrafts.getBusiness_class_capacity());
            staircraft.setLong(4, aircrafts.getEconom_class_capacity());
            ResultSet rs = staircraft.executeQuery();
            rs.next();
            if (rs.next()) System.out.println("AIRPLANE added");
            staircraft.close();
        } catch (Exception aircraftexception) {
            aircraftexception.printStackTrace();
        }
    }

    public void addCities(Cities cities) {
        try {
            PreparedStatement stcities = connection.prepareStatement("INSERT INTO cities(id,name,country,short_name) VALUES(NULL,?,?,?)");
            stcities.setString(1, cities.getName());
            stcities.setString(2, cities.getCountry());
            stcities.setString(3, cities.getShort_name());
            stcities.executeUpdate();

            stcities = connection.prepareStatement("SELECT * FROM cities WHERE name=? AND country=? AND short_name=?");
            stcities.setString(1, cities.getName());
            stcities.setString(2, cities.getCountry());
            stcities.setString(3, cities.getShort_name());
            ResultSet rs1 = stcities.executeQuery();
            rs1.next();
            if (rs1.next()) System.out.println("CITY ADDED");
            stcities.close();
        } catch (Exception citiesexception) {
            citiesexception.printStackTrace();
        }
    }

    public void addFlight(Flights flights) {
        try {
            PreparedStatement stflight = connection.prepareStatement("INSERT INTO flights(id,aircraft_id," +
                    "departure_city_id,arrival_city_id,departure_time,econom_place_price,business_place_price) VALUES(NULL,?,?,?,?,?,?)");
            stflight.setLong(1, flights.getAircraft_id());
            stflight.setLong(2, flights.getDeparture_city_id());
            stflight.setLong(3, flights.getArrival_city_id());
            stflight.setString(4, flights.getDeparture_time());
            stflight.setLong(5, flights.getEconom_place_price());
            stflight.setLong(6, flights.getBusiness_place_price());
            stflight.executeUpdate();

            stflight = connection.prepareStatement("SELECT * FROM flights WHERE aircraft_id=? AND departure_city_id=? " +
                    "AND arrival_city_id=? AND departure_time=? AND econom_place_price=? AND business_place_price=? ");
            ResultSet rs2 = stflight.executeQuery();
            rs2.next();
            if (rs2.next()) System.out.println("FLIGHT ADDED");
            stflight.close();

        } catch (Exception flightexception) {
            flightexception.printStackTrace();
        }
    }
}

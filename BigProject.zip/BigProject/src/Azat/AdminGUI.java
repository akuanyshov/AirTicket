package Azat;

import javax.swing.*;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

public class AdminGUI extends JFrame {
    AdminMainPage adminMainPage;
    AdminSecondPage adminSecondPage;
    AddAircrafts addAircrafts;
    AddCities addCities;
    AddFlights addFlights;
    ObjectOutputStream outStream;
    ObjectInputStream inStream;

    public AdminGUI() {

        setSize(500, 500);
        setTitle("ADMIN APPLICATION");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(null);
        Socket socket = null;
        try {
            socket = new Socket("localhost", 2024);
            outStream = new ObjectOutputStream(socket.getOutputStream());
            inStream = new ObjectInputStream(socket.getInputStream());
        } catch (Exception e) {
            e.printStackTrace();
        }

        adminMainPage = new AdminMainPage(this);
        add(adminMainPage);
        adminMainPage.setVisible(true);

        adminSecondPage = new AdminSecondPage(this);
        add(adminSecondPage);
        adminSecondPage.setVisible(false);

        addAircrafts = new AddAircrafts(this);
        add(addAircrafts);
        addAircrafts.setVisible(false);

        addCities = new AddCities(this);
        add(addCities);
        addCities.setVisible(false);

        addFlights = new AddFlights(this);
        add(addFlights);
        addFlights.setVisible(false);
    }


    public void setAddFlights(Flights fd) {
        try {
            outStream.writeObject(fd);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void addAircrafts(AircraftsDate ad) {
        try {
            outStream.writeObject(ad);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void addCities(CitiesDate cd) {
        try {
            outStream.writeObject(cd);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
